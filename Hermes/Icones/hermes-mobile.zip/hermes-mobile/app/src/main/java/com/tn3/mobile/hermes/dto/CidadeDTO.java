package com.tn3.mobile.hermes.dto;

public class CidadeDTO {

    public String ibge;
    public String uf;
    public String nome;

    public CidadeDTO(String ibge, String uf, String nome) {
        this.ibge = ibge;
        this.uf = uf;
        this.nome = nome;
    }
}
