package com.tn3.mobile.hermes;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.telephony.TelephonyManager;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import android.app.AlertDialog;

import com.tn3.mobile.hermes.utils.ConnectionCheckUtils;
import com.tn3.mobile.hermes.utils.Utils;

public class AbstractActivity extends AppCompatActivity {

    //definicao da identificacao da classe nos logs
    final String TAG = this.getClass().getSimpleName();

    Utils utils = new Utils(this);

    void alert(String msg, int duraction) {
        utils.alert(msg, duraction);
    }

    boolean isConnected() {
        return utils.isConnected();
    }

    String getImei(){
        return utils.getImei();
    }
}
